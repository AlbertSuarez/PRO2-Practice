var searchData=
[
  ['practica_20de_20pro2_2e',['PRACTICA de PRO2.',['../index.html',1,'']]],
  ['posicions',['posicions',['../class_ranking.html#aaa3215582de4fcca82b9d8637584c12b',1,'Ranking']]],
  ['potcreixer',['potcreixer',['../class_organisme.html#a7b2b434f51af578ace7b37993aedd4f9',1,'Organisme']]],
  ['pro2_2ecpp',['pro2.cpp',['../pro2_8cpp.html',1,'']]]
];
