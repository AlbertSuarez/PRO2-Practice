var searchData=
[
  ['leer_5fcelula',['leer_celula',['../class_celula.html#a975bfa82da9b298581d0df62102a394c',1,'Celula']]],
  ['leer_5fexperiment',['leer_experiment',['../class_experiment.html#a02185fb874c9439991a68ab436d084bf',1,'Experiment']]],
  ['leer_5forganisme',['leer_organisme',['../class_organisme.html#ae53bdafd0b8cf07483aa02ef5e8498cb',1,'Organisme']]]
];
