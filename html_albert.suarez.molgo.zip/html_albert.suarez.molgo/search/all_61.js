var searchData=
[
  ['activa',['activa',['../class_celula.html#a22ec0fe5fde605b5b3067acde093a3f7',1,'Celula']]],
  ['actualizar_5franking',['actualizar_ranking',['../class_ranking.html#a2d2aec44c0e24f7a60141b49221e3dbf',1,'Ranking']]]
];
