var searchData=
[
  ['celula',['Celula',['../class_celula.html#a3c5017fbcec8cb564acc666aa7e21206',1,'Celula::Celula()'],['../class_celula.html#a9fac2a026e4205b7ca6f9c582d2bf5c0',1,'Celula::Celula(int iden, bool activ)']]],
  ['compatibles',['compatibles',['../class_organisme.html#a054a7723a2083af4c182b8f0266ec54c',1,'Organisme']]],
  ['consultar_5factiva',['consultar_activa',['../class_celula.html#a750270ff8277447af6cc3a122d585aab',1,'Celula']]],
  ['consultar_5fid',['consultar_id',['../class_celula.html#adfe788cb113f6e8dcf9def377a248255',1,'Celula::consultar_id()'],['../class_organisme.html#aebe855cdb3f44a278c18d21912f60301',1,'Organisme::consultar_id()']]],
  ['consultar_5fmaxid',['consultar_maxid',['../class_organisme.html#a42ffae8888c18bafb3cca2d4140cd2cf',1,'Organisme']]],
  ['consultar_5fpotcreixer',['consultar_potcreixer',['../class_organisme.html#a650fae6627523a55b2941c47d0cc3b82',1,'Organisme']]],
  ['consultar_5ftamano',['consultar_tamano',['../class_organisme.html#ac215686620dc98397493f2b6cfe37735',1,'Organisme']]],
  ['consultar_5fvius',['consultar_vius',['../class_experiment.html#a1f1307d2224b32b4b642b7e545f655f6',1,'Experiment']]],
  ['crece',['crece',['../class_organisme.html#ab90a2daa639560e569d8de05297b47b6',1,'Organisme']]]
];
