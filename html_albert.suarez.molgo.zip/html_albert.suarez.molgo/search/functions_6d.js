var searchData=
[
  ['main',['main',['../pro2_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'pro2.cpp']]],
  ['modificar_5factiva',['modificar_activa',['../class_celula.html#a5bccaca548ef9f6c06e06a64265fabe3',1,'Celula']]],
  ['modificar_5fid',['modificar_id',['../class_celula.html#ad8549ea461baa63298e8548691a270e2',1,'Celula']]],
  ['muerto',['muerto',['../class_experiment.html#af08a77ada723ccaaf6476a3c1331261c',1,'Experiment']]]
];
