var searchData=
[
  ['id',['id',['../class_celula.html#a0984a8b3deeed4979ed6f6141edc3c0c',1,'Celula::id()'],['../class_organisme.html#ac2f0882eb2985d187f189fd238ceece3',1,'Organisme::id()']]]
];
