var searchData=
[
  ['posicions',['posicions',['../class_ranking.html#aaa3215582de4fcca82b9d8637584c12b',1,'Ranking']]],
  ['potcreixer',['potcreixer',['../class_organisme.html#a7b2b434f51af578ace7b37993aedd4f9',1,'Organisme']]]
];
