var searchData=
[
  ['activa',['activa',['../class_celula.html#a22ec0fe5fde605b5b3067acde093a3f7',1,'Celula']]]
];
