var searchData=
[
  ['i_5fescribir_5forganisme',['i_escribir_organisme',['../class_organisme.html#ac88ecbfd1eafc62ba3744ed104626ab5',1,'Organisme']]],
  ['i_5fleer_5forganisme',['i_leer_organisme',['../class_organisme.html#a75f7f37f4c89327fcc3376ea98ccc97c',1,'Organisme']]],
  ['i_5freproduccion',['i_reproduccion',['../class_organisme.html#a3344f2b519e7b3bd296803d5e37ecfc1',1,'Organisme']]],
  ['interseccion',['interseccion',['../class_organisme.html#a00b103256f3fb0b95a074a9b06de14ac',1,'Organisme']]]
];
