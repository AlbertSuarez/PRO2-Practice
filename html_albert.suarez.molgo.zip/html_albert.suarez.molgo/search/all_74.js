var searchData=
[
  ['tamano',['tamano',['../class_organisme.html#a03277939e7c5be36d0ee183ae6fa99c4',1,'Organisme::tamano()'],['../class_experiment.html#a32df1020a5b5e27949bd2bce272a36d9',1,'Experiment::tamano()']]],
  ['tamano_5fmaximo',['tamano_maximo',['../class_experiment.html#a333c9c8084c76beb6b8848b8f2efec25',1,'Experiment']]],
  ['te_5factiva',['te_activa',['../class_organisme.html#a52d94598bdac2bcf8264f3cc48b7193a',1,'Organisme']]]
];
