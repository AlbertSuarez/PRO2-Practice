var searchData=
[
  ['actualizar_5franking',['actualizar_ranking',['../class_ranking.html#a2d2aec44c0e24f7a60141b49221e3dbf',1,'Ranking']]]
];
